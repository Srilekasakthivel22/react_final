import axios from 'axios';
import React, { Component } from 'react'
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'



export default class AppOrDeny extends Component {
    constructor()
    {
        super();
        this.state={
            leaves:[],
            leaveId:0,
            employeeId:0,
            
            Status:"",
            managerComment:"",
            i:true
        }
      this.handleChange=this.handleChange.bind(this);
       this.ApproveDeny=this.ApproveDeny.bind(this);
 }
 ApproveDeny(e)
 {
     
    let id=sessionStorage.getItem("Id");
     let name=sessionStorage.getItem("Mname");
     let url="http://localhost:20969/api/Employee/GetEmpbyMangid?mangId="+id;
     axios.get(url).then(response=>{
        this.setState({leave:response.data});
    }).catch(error=>{
        alert(error);
    })
    //     this.setState({Leave:response.data})
    //  leaveId:this.state.leaveId,
    //  employeeId:this.state.employeeId,
    //     managerId:this.state.managerId,
    //     status:this.state.startDate,
    //     endDate:this.state.endDate,
    //     noOfDays:this.state.noOfDays,
    //     leaveType:this.state.leaveType,
    //     leaveReason:this.state.leaveReason,
    //     status:this.state.startDate,
    //     managerComment:this.state.managerComment
   
 }
 handleChange(e)
 {
     this.setState(e);
 }
 componentDidMount()
 {
    this.ApproveDeny();
 }


 
    render() {
        const {leave}=this.state;
        return (
            <div> <div>
            <div>ShowAllDetails</div>
            
        <table  border="1" align='center'>
            <tbody>
            
            <tr>
            <th>LeaveId</th>
            <th>EmployeeId</th>
            <th>ManagerID</th>
            
            <th>StartDay</th>
            <th>EndDay</th>
            <th>noOfDay</th>
            <th>LeaveType</th>
            
            <th>leaveReason</th>
            <th>Status</th>
           
         
            <th>ManagerComments</th>
            <th>change Status</th>
            </tr>
            {leave.map(a => <tr>
               <td>{a.leaveId}</td>
                <td>{a.employeeId}</td>
                <td>{a.managerId}</td>
               
                <td>{a.startDate}</td>
                <td>{a.endDate}</td>
                <td>{a.noOfDay}</td>
                <td>{a.leaveType}</td>
                
                <td>{a.leavereason}</td>
                <td>{a.status}</td>
                {/* <td>{a.managerComments}</td> */}
                <td><Button variant="primary btn-block" onClick={this.ApproveDeny} type="submit" > Change status</Button></td>
            </tr>
            )}
            </tbody>
           
            
        </table>
        </div></div>
            // <div>
            //     <form>
            //     <label>Status</label>
            //         <input type="text" name="Status" onChange={(e)=>this.handleChange({status:e.target.value})} placeholder=" Enter your Status"></input>
            //         <br></br>
            //         <label>Manager Comment</label>
            //         <input type="text" name="Status" onChange={(e)=>this.handleChange({status:e.target.value})} placeholder=" Enter your Comments"></input>
            //         <br></br>
            //         <button type="submit" className="button" onClick={this.ApproveDeny} >Apply</button>
                        
            //     </form>
            // </div>
        )
    }
}
