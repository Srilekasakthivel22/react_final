import React from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import './Login.css'
import Homeimage from './image/Homeimage.png';
import Homepic from './image/Homepic.jpg';

import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'

export default function Login() {
    return ( 
  
      
    
  
        <div className="hero">
            <nav>
                 <div >
        
           <h1 className="s">  Welcome to Login Portal</h1>
            <div className="h"> 
            <ul>
             <Link to="/ManagerLogin">ManagerLogin</Link><br/>
             <Link to="/EmpLogin">EmpLogin</Link>
             </ul> 
             </div>
           
            </div>
               
            </nav>
        </div>
        
    
    
    )
}
