import React, { Component } from 'react'

export default class DeleteLeave extends Component {
    constructor()
    {
        super();
        this.state={
            leaveid:""
        }
        this.delete=this.delete.bind(this);
    }
    delete()
    {
        
    }
    render() {
        
        return (
            <div>
                
            </div>
        )
    }
}
