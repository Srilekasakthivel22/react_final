import axios from 'axios';
import React, { Component } from 'react'
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'


export default class ViewLeave extends Component {
    constructor(props)
    {
        super(props);
        this.state={
            Leaves:[],
            // leaveId:"",
            // employeeId:"",
            // managerId:"",
            // startDate:"",
            // endDate:"",
            // noOfDays:"",
            // leaveType:"",
            // leaveReason:"",
            // status:"",
        }
        this.SearchById=this.SearchById.bind(this);
        // this.handleChange=this.handleChange.bind(this);
        this.SignOut=this.SignOut.bind(this);
        
        this.delete=this.delete.bind(this);
    }
SearchById(e)
{
    let id=sessionStorage.getItem("EmpId");
    let url=("http://localhost:20969/api/Leave/"+id+"?id=1")
    axios.get(url)
    .then(response=>{
        this.setState({Leave:response.data})
    // .then(response=>{
    //     this.setState({
       
        
    //         leaveId:response.data.leaveId,
    //         employeeId:response.data.employeeId,
    //         managerId:response.data.managerId,
    //         startDate:response.data.setState,
    //         endDate:response.data.endDate,
    //         noOfDays:response.data.noOfDays,
    //         leaveType:response.data.leaveType,
    //         leaveReason:response.data.leaveReason,
    //         status:response.data.status,
    //     })
    
    }).catch(err=>{
        console.warn(err);
    })
    if(id==null)
    {
        alert("pls login first");
        window.location="/"
    }
     // this.setState({Leave:response.data})
        // sessionStorage.setItem("Id",response.data.leaveId);
        // then(result=>
    // if(id==null)
    //     {
    //         alert("Pls Login First");
    //         window.location="/EmpLogin";
    //     }
}
SignOut()
{
    sessionStorage.removeItem("EmpId");
        sessionStorage.removeItem("MangId");
        sessionStorage.removeItem("Empname");
        sessionStorage.removeItem("email");
        window.location="/EmpLogin";
}
// handleChange(e)
// {
//     this.setState(e);
// }
componentDidMount()
{
    this.SearchById();     
    
}
delete()
{
//    sessionStorage.setItem("Id",result.data.leaveId);
   let Id=sessionStorage.getItem("Id");
   let url="http://localhost:20969/api/Leave/1?id="+Id;
   axios.delete(url).then(response=>{
       alert("deleted");
   }).catch(err=>{
       alert(err);
   });
}


    render() {
        const {Leaves}=this.state;
        // const {leaveId}=this.state;
        // const {employeeId}=this.state;
        // const {managerId}=this.state;
        // const {startDate}=this.state;
        // const {endDate}=this.state;
        // const {noOfDays}=this.state;
        // const {leaveType}=this.state;
        // const {leaveReason}=this.state;
        // const {status}=this.state;
        return (
            <div >
                <nav>
              
             
              <Button variant="primary btn-block" onClick={this.SignOut} type="submit" > SignOut </Button>
             
             </nav>
            <div>
                <div>ShowAllDetails</div>
                
            <table  border="1" align='center'>
                <tbody>
                
                <tr>
                <th>LeaveId</th>
                <th>EmployeeId</th>
                <th>ManagerID</th>
                
                <th>StartDay</th>
                <th>EndDay</th>
                <th>noOfDays</th>
                <th>LeaveType</th>
                
                <th>leaveReason</th>
                <th>Status</th>
               
             
                <th>ManagerComments</th>
                <th>Delete</th>
                </tr>{Leaves.map(a => <tr>
                   <td>{a.leaveId}</td>
                    <td>{a.employeeId}</td>
                    <td>{a.managerId}</td>
                   
                    <td>{a.startDate}</td>
                    <td>{a.endDate}</td>
                    <td>{a.noOfDays}</td>
                    <td>{a.leaveType}</td>
                    
                    <td>{a.leaveReason}</td>
                    <td>{a.status}</td>
                    {/* <td>{a.managerComments}</td> */}
                    <td><Button variant="primary btn-block" onClick={this.delete} type="submit" > delete</Button></td>
                </tr>
                )}
                </tbody>
               
                
            </table>
            </div>
            </div>
           
        )
    }
}
