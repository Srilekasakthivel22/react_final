import React, { Component } from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'
import EmpLogin from './EmpLogin';
import './EmpDashBoard.css';
import Loginimage from './image/Loginimage.jpg'



export default class EmpDashBoard extends Component {
    constructor()
    {
        super();
        this.state={
            Employee:[],
            Id:""

        }
        this.SignOut=this.SignOut.bind(this);
    }
    SignOut()
    {
        sessionStorage.removeItem("EmpId");
        sessionStorage.removeItem("MangId");
        sessionStorage.removeItem("Empname");
        sessionStorage.removeItem("email");
        window.location="/EmpLogin";

    }
    componentDidMount()
    {
        let Id=   sessionStorage.getItem("EmpId");
        let MgId=sessionStorage.getItem("MangId");
        let name=sessionStorage.getItem("Empname");
        let email=sessionStorage.getItem("email");
        if(this.email==null)
        {
            alert("Pls Login First");
            window.location="/EmpLogin";
        }
    }

    render() {
           this.id=sessionStorage.getItem("EmpId");
            this.name=sessionStorage.getItem("Empname");
            this.email=sessionStorage.getItem("email");
        return (

            <Container className="mt-5">
                   <Row>
                       <Col lg={4} md={6} sm={12} className="text-center mt-5 p-18">
                           
                           <div classname="b">
            
            <div >
              <label className="la"> Welcome {this.name},</label>
             
              <Button variant="primary btn-block" onClick={this.SignOut} type="submit" > SignOut </Button>
             </div>
           
            
            <div  >
                <div className="yah">
               <Link to="/MyProfile" className="punith">MyProfile</Link> <br></br>
               </div>
                <div className="yah">
               <Link to="/MyManagerDetails" className="punith" >MyManagerDetails</Link><br></br>
               </div>
               <div className="yah">
                <Link to="/LeaveTracker" className="punith">LeaveTracker</Link><br></br>
                </div>
                
                
            </div>
            </div>


      
   
                       </Col>
                       <Col lg={8} md={6} sm={12}>
                        <img className="w100" src={Loginimage} alt=""/>
                       </Col>

                   </Row>
               </Container>
               
       
            // <div classname="b">
            // <nav>
            // <div >
            //   <label className="la">DashBoard Welcome {this.name},</label>
             
            //   <Button variant="primary btn-block" onClick={this.SignOut} type="submit" > SignOut </Button>
            //  </div>
            //  </nav>
            
            // <div  >
            //     <div className="yah">
            //    <Link to="/MyProfile" className="punith">MyProfile</Link> <br></br>
            //    </div>
            //     <div className="yah">
            //    <Link to="/MyManagerDetails" className="punith" >MyManagerDetails</Link><br></br>
            //    </div>
            //    <div className="yah">
            //     <Link to="/LeaveTracker" className="punith">LeaveTracker</Link><br></br>
            //     </div>
                
                
            // </div>
            // </div>

            
            
            
            
        )
    }
}
